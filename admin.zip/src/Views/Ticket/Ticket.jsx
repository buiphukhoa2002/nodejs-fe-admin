import React from "react";

const Ticket = () => {
  return <div></div>;
};

export default Ticket;
